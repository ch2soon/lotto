<?php
header( 'Location: ./src/upload.php' );