<?php
set_time_limit(0);
date_default_timezone_set('Asia/Seoul');

require_once "../vendor/autoload.php";
require_once "../util/azure_storage.php";
require_once "../util/config.php";

define("STORE_IMAGE_PATH_ROOT", "image5", false);
define("STORE_ORIGINAL_IMAGE_PATH_ROOT", "rawimage5", false);

$json_data = array();
$msg = "";
$success_flag = false;
$to_day = date("Y-m-d H:i:s");

$gal_pen_name = "";
$gal_type_cd = "";
$reg_mem_idx = "";
$reg_mem_id = "";
if(isset($_REQUEST["gal_pen_name"])) $gal_pen_name = $_REQUEST["gal_pen_name"];
if(isset($_REQUEST["gal_type_cd"])) $gal_type_cd = $_REQUEST["gal_type_cd"];
if(isset($_REQUEST["reg_mem_idx"])) $reg_mem_idx = $_REQUEST["reg_mem_idx"];
if(isset($_REQUEST["reg_mem_id"])) $reg_mem_id = $_REQUEST["reg_mem_id"];
if(trim($gal_pen_name) === "") $gal_pen_name = $reg_mem_id;

$blob_path = "_upload";
$blob_path_origin = $blob_path."/".STORE_ORIGINAL_IMAGE_PATH_ROOT;
$blob_path_default = $blob_path."/".STORE_IMAGE_PATH_ROOT;

$blob_db_path = "/_upload";
$blob_db_path_origin = $blob_db_path."/".STORE_ORIGINAL_IMAGE_PATH_ROOT;
$blob_db_path_default = $blob_db_path."/".STORE_IMAGE_PATH_ROOT;

$db = get_dbc();

$time_start = date("Y-m-d H:i:s");
$acah_idx = "";
$driectory_cnt = 0;
$total_file_cnt = 0;
$err_file_cnt = 0;

if(isset($_REQUEST["data_path"])) {
    $dir = preg_replace("/\\\\/", "/", trim($_REQUEST["data_path"]));

    // DB 작업을 해야하므로 함수화 시키지 않음
    if(is_dir($dir)) {
        if($dh = opendir($dir)) {
            $query = "
                SELECT nextval('seq_auto_cummunity_add_history') AS acah_idx
            ";
            $hresult_set = pg_query($db, $query) or die("sql error : ".pg_last_error()."<br/>");
            $hresult = pg_fetch_array($hresult_set, 0, PGSQL_NUM);
            pg_free_result($hresult_set);
            $acah_idx = $hresult[0];

            // history parent
            $query = "
                INSERT INTO tb_auto_cummunity_add_history (
                    acah_idx
                    , client_addr
                    , reg_dt
                    , time_start
                ) VALUES (
                    '$acah_idx'
                    , INET_CLIENT_ADDR()
                    , '$time_start'
                    , '$time_start'
                )
            ";
            pg_query($db, $query) or die("sql error : ". pg_last_error(). "<br/>");

            while (($sub_dir = readdir($dh)) !== false) {

                $sub_full_dir = $dir."/".$sub_dir;
                $sub_full_dir = str_replace("//", "/", $sub_full_dir);

                if ($sub_dir <> "." && $sub_dir <> ".." && is_dir($sub_full_dir)) {
                    $driectory_cnt = $driectory_cnt + 1;
                    // 디렉토리 당 커뮤니티 1개 게시물
                    // 게시물 번호 가져오기
                    $query = "
                        SELECT
                            nextval('seq_photo_gallery') AS gal_idx
                            , nextval('seq_photo_gallery_no_type_01') AS gal_no
                            , CASE
                                WHEN (SELECT COALESCE(MIN(gal_idx_no),0) FROM tb_photo_del_idxno WHERE re_usable_yn = 'Y')=0 THEN nextval('seq_gal_idx_no')  
                                ELSE (SELECT COALESCE(MIN(gal_idx_no),0) FROM tb_photo_del_idxno WHERE re_usable_yn = 'Y')
                            END gal_idx_no
                    ";
                    $result_set = pg_query($db, $query) or die("sql error : ".pg_last_error()."<br/>");
                    $result = pg_fetch_array($result_set, 0, PGSQL_NUM);
                    pg_free_result($result_set);

                    $local_file_dir = "";
                    $gal_idx = date("ymd")."00".$result[0];
                    $gal_no = $result[1];
                    $gal_idx_no = $result[2];
                    $cnt = 0;
                    if(is_dir($sub_full_dir)) {
                        $local_file_dir = $sub_full_dir."/".date("y").date("m");
                        if(is_dir($local_file_dir)) rmdir_all($local_file_dir);         // 기존에 자동 생성한 내역이 남아 있으면 삭제

                        if($sfdh = opendir($sub_full_dir)) {
                            while (($files = readdir($sfdh)) !== false) {
                                $file_full_path = $sub_full_dir."/".$files;
                                if ($files <> "." && $files <> ".." && !is_dir($file_full_path)) {
                                    $ext = explode(".", $files);
                                    $ext_string = strtolower($ext[count($ext)-1]);
                                    $ext = ".".strtolower($ext[count($ext)-1]);

                                    if(strtolower($ext_string) === "jpeg" || strtolower($ext_string) === "jpg" || strtolower($ext_string) === "png" || strtolower($ext_string) === "gif") {
                                        $img_nm = filter_SQL($files);
                                        $img_nm_lowcase = strtolower($img_nm);

                                        $query = "
                                            SELECT nextval('seq_image') AS img_idx
                                        ";
                                        $sresult_set = pg_query($db, $query) or die("sql error : ".pg_last_error()."<br/>");
                                        $sresult = pg_fetch_array($sresult_set, 0, PGSQL_NUM);
                                        pg_free_result($sresult_set);

                                        $img_idx = date("ymd")."0".$sresult[0];
                                        $file_rename = $img_idx;

                                        $file_date_dir = "/".date("y").date("m")."/".date("d")."/".$file_rename;
                                        $local_file_date_dir = $sub_full_dir.$file_date_dir;

                                        @mkdir($local_file_date_dir, 0777, true);

                                        $file_full_rename = $file_rename.$ext;

                                        copy($file_full_path, $local_file_date_dir."/".$file_full_rename);

                                        $res = thumbnail($sub_full_dir."/".$img_nm, $local_file_date_dir."/".$file_rename."_thumb_400".$ext, 400, 0);
                                        if($res->result === "success") {
                                            $cnt = $cnt + 1;

                                            watermark($local_file_date_dir."/".$file_rename."_thumb_400".$ext, $local_file_date_dir."/".$file_rename."_thumb_400_w".$ext, 400);
                                            thumbnail($sub_full_dir."/".$img_nm, $local_file_date_dir."/".$file_rename."_thumb_1024".$ext, 1024, 0);
                                            watermark($local_file_date_dir."/".$file_rename."_thumb_1024".$ext, $local_file_date_dir."/".$file_rename."_thumb_1024_w".$ext, 1024);

                                            pathUploadBlob($local_file_date_dir."/".$file_full_rename, $blob_path_origin.$file_date_dir, $file_full_rename);
                                            pathUploadBlob($local_file_date_dir."/".$file_rename."_thumb_400".$ext, $blob_path_default.$file_date_dir, $file_rename."_thumb_400.jpg");
                                            pathUploadBlob($local_file_date_dir."/".$file_rename."_thumb_400_w".$ext, $blob_path_default.$file_date_dir, $file_rename."_thumb_400_w.jpg");
                                            pathUploadBlob($local_file_date_dir."/".$file_rename."_thumb_1024".$ext, $blob_path_default.$file_date_dir, $file_rename."_thumb_1024.jpg");
                                            pathUploadBlob($local_file_date_dir."/".$file_rename."_thumb_1024_w".$ext, $blob_path_default.$file_date_dir, $file_rename."_thumb_1024_w.jpg");
                                            
                                            $size = getimagesize($file_full_path);
                                            $width = $size[0];
                                            $height = $size[1];
                                            $origin_path = $blob_db_path_origin.$file_date_dir."/".$file_full_rename;
                                            $t120 = $blob_db_path_default.$file_date_dir."/".$file_rename."_thumb_400".$ext;
                                            $t400 = $blob_db_path_default.$file_date_dir."/".$file_rename."_thumb_400".$ext;
                                            $t800 = $blob_db_path_default.$file_date_dir."/".$file_rename."_thumb_1024".$ext;
                                            $t1024 = $blob_db_path_default.$file_date_dir."/".$file_rename."_thumb_1024".$ext;
                                            $t400w = $blob_db_path_default.$file_date_dir."/".$file_rename."_thumb_400_w".$ext;
                                            $t1024w = $blob_db_path_default.$file_date_dir."/".$file_rename."_thumb_1024_w".$ext;

                                            $to_day = date("Y-m-d H:i:s");
                                            $query = "
                                                INSERT INTO tb_image (
                                                    img_idx
                                                    , gal_idx
                                                    , gal_type_cd
                                                    , img_nm
                                                    , img_format
                                                    , img_reg_dt
                                                    , img_reg_mem_idx
                                                    , img_origin_width
                                                    , img_origin_height
                                                    , img_file_nm
                                                    , img_filepath
                                                    , img_filepath_120_80
                                                    , img_filepath_400_300
                                                    , img_filepath_800_600
                                                    , img_filepath_1024_768
                                                    , img_source_cd
                                                    , img_select_cd
                                                    , img_src_file_seq
                                                    , img_origin_web_reg_yn
                                                    , img_use_yn
                                                    , img_filepath_400_300_w
                                                    , img_filepath_1024_768_w
                                                    , old_imageno
                                                    , img_nm_lowcase
                                                    , img_market_read_cnt
                                                    , img_market_main_display_yn
                                                    , img_sale_cnt
                                                    , img_filepath_origin
                                                    , img_usercopyright
                                                    , img_master_img_yn
                                                    , img_sale_yn
                                                ) VALUES (
                                                    '$img_idx'
                                                    , '$gal_idx'
                                                    , '$gal_type_cd'
                                                    , '$img_nm'
                                                    , '$ext_string'
                                                    , '$to_day'
                                                    , '$reg_mem_idx'
                                                    , '$width'
                                                    , '$height'
                                                    , '$img_nm'
                                                    , '$origin_path'
                                                    , '$t120'
                                                    , '$t400'
                                                    , '$t800'
                                                    , '$t1024'
                                                    , '03'
                                                    , '01'
                                                    , $cnt
                                                    , 'N'
                                                    , 'Y'
                                                    , '$t400w'
                                                    , '$t1024w'
                                                    , nextval('seq_imageno')
                                                    , '$img_nm_lowcase'
                                                    , 0
                                                    , 'N'
                                                    , 0
                                                    , '$origin_path'
                                                    , null
                                                    , 'N'
                                                    , 'N'
                                                )
                                            ";
                                            pg_query($db, $query) or die("sql error : ". pg_last_error(). "<br/>");
                                        } else {
                                            $err_file_cnt = $err_file_cnt + 1;
                                            // 손상파일 정보 등록
                                            $err_file_path = $sub_full_dir."/".$img_nm;
                                            $query = "
                                                INSERT INTO tb_auto_cummunity_add_err_history (
                                                    gal_idx
                                                    , acah_idx
                                                    , err_file_path
                                                    , reg_dt
                                                ) VALUES (
                                                    '$gal_idx'
                                                    , '$acah_idx'
                                                    , '$err_file_path'
                                                    , '$to_day'
                                                )
                                            ";
                                            pg_query($db, $query) or die("sql error : ". pg_last_error(). "<br/>");
                                        }
                                    }
                                }
                            }
                            closedir($sfdh);
                        }
                    }
                    
                    $query = "
                        UPDATE 
                            tb_photo_gallery
                        SET gal_idx_no=null
                        WHERE gal_idx_no = $gal_idx_no::numeric
                        AND gal_del_yn = 'Y'
                    ";
                    pg_query($db, $query) or die("sql error : ". pg_last_error(). "<br/>");

                    if($cnt > 0) {
                        // 읽어온 디렉토리의 `_` 기준으로 나누어 갤러리 데이터를 구분 (config.php에서 작업 : 협의 필요) //
                        $data = set_field_data($sub_dir);
                        // ***************** //

                        $to_day = date("Y-m-d H:i:s");
                        $query = "
                            INSERT INTO tb_photo_gallery (
                                gal_idx
                                , gal_type_cd
                                , gal_subject
                                , gal_reg_mem_idx
                                , gal_no
                                , gal_del_yn
                                , gal_reg_dt
                                , gal_img_cnt
                                , gal_idx_no
                                , gal_pen_name
                                , gal_open_yn
                            ) VALUES (
                                '$gal_idx'
                                , '$gal_type_cd'
                                , '$data->subject'
                                , '$reg_mem_idx'
                                , $gal_no
                                , 'N'
                                , '$to_day'
                                , $cnt
                                , $gal_idx_no
                                , '$gal_pen_name'
                                , 'N'
                            )
                        ";
                        pg_query($db, $query) or die("sql error : ". pg_last_error(). "<br/>");
                    }
                    $total_file_cnt = $total_file_cnt + $cnt;

                    $query = "
                        DELETE FROM 
                            tb_photo_del_idxno 
                        WHERE re_usable_yn = 'Y'
                        AND gal_idx_no = $gal_idx_no::numeric
                    ";
                    pg_query($db, $query) or die("sql error : ". pg_last_error(). "<br/>");

                    $to_day = date("Y-m-d H:i:s");
                    // history child
                    $query = "
                        INSERT INTO tb_auto_cummunity_add_data_history (
                            gal_idx
                            , acah_idx
                            , reg_dt
                        ) VALUES (
                            '$gal_idx'
                            , '$acah_idx'
                            , '$to_day'
                        )
                    ";
                    pg_query($db, $query) or die("sql error : ". pg_last_error(). "<br/>");

                    rmdir_all($local_file_dir);
                }
                // 게시물당 등록 후 3초 지연
                sleep(3);
            }
            $to_day = date("Y-m-d H:i:s");
            // history parent
            $query = "
                UPDATE 
                    tb_auto_cummunity_add_history
                SET reg_dt = '$to_day'
                    , time_end = '$to_day'
                WHERE acah_idx = '$acah_idx'
            ";
            pg_query($db, $query) or die("sql error : ". pg_last_error(). "<br/>");
            
            closedir($dh);
            $success_flag = true;
            $msg = "성공";
        } else {
            $msg = "디렉토리 오픈하지 못했습니다.";
            $success_flag = false;
        }
    } else {
        $msg = "디렉토리 경로가 확인되지 않습니다.";
        $success_flag = false;
    }
} else {
    $msg = "데이터가 정상적이지 않습니다.";
    $success_flag = false;
}

pg_close($db);

if($success_flag) {
    $json_data["success"] = true;
    $result = (object) array(
        'acah_idx' => $acah_idx
        , 'driectory_cnt' => $driectory_cnt
        , 'total_file_cnt' => $total_file_cnt
        , 'err_file_cnt' => $err_file_cnt
        , 'time_start' => $time_start
        , 'time_end' => $to_day
    );
    $json_data["result"] = $result;
} else $json_data["success"] = false;
$json_data["msg"] = $msg;

echo json_encode($json_data);