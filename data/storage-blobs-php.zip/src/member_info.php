<?php
require_once "../util/config.php";

$member_id = $_POST["memberId"];

$db = get_dbc();

$query = "SELECT mem_idx, mem_nm FROM tb_member WHERE mem_id = '".$member_id."'";
$result_set = pg_query($db, $query) or die("sql error : ".pg_last_error()."<br/>");
$arr = new StdClass();
$data_arr = null;
if(pg_num_rows($result_set) === 0) {
    $arr->success = false;
} else {
    $data_arr = [];
    if(pg_num_rows($result_set) > 1) {
        while ($row = pg_fetch_row($result_set)) {
            array_push($data_arr, [ "mem_idx" => $row[0], "mem_nm" => $row[1] ]);
        }
    } else {
        $result = pg_fetch_array($result_set, 0, PGSQL_NUM);
        $data_arr = new StdClass();
        $data_arr->mem_idx = $result[0];
        $data_arr->mem_nm = $result[1];
    }
    $arr->success = true;
    $arr->result = $data_arr;
}
echo json_encode($arr);

pg_free_result($result_set);
pg_close($db);