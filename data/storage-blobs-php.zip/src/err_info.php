<?php
require_once "../util/config.php";

$acah_idx = $_POST["acah_idx"];

$db = get_dbc();

$query = "SELECT err_file_path FROM tb_auto_cummunity_add_err_history WHERE acah_idx = '".$acah_idx."'";
$result_set = pg_query($db, $query) or die("sql error : ".pg_last_error()."<br/>");
$arr = new StdClass();
$data_arr = null;
if(pg_num_rows($result_set) === 0) {
    $arr->success = false;
} else {
    $data_arr = [];
    if(pg_num_rows($result_set) > 1) {
        while ($row = pg_fetch_row($result_set)) {
            array_push($data_arr, [ "err_file_path" => $row[0] ]);
        }
    } else {
        $result = pg_fetch_array($result_set, 0, PGSQL_NUM);
        $data_arr = new StdClass();
        $data_arr->err_file_path = $result[0];
    }
    $arr->success = true;
    $arr->result = $data_arr;
}
echo json_encode($arr);

pg_free_result($result_set);
pg_close($db);