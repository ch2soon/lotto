<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="/image/doo.ico" type="image/x-icon">
    <title>포토커뮤니티 등록</title>
    <link href="/css/upload.css" rel="stylesheet" />
</head>
<body>
    <section>
        <h1>커뮤니티 게시물 자동 등록</h1>
        <!-- <div class="button-area">
            <button type="button" class="btn-hover color-11 history">등록내역</button>
        </div> -->
        <form id="upload-form">
            <input type="hidden" name="data_path">
            <div class="file-path">
                <div>
                    <label for="driver">드라이브</label>
                    <select id="driver" title="드라이브명">
                        <option value="">선택</option>
                        <option value="C">C:</option>
                        <option value="D">D:</option>
                        <option value="E">E:</option>
                        <option value="F">F:</option>
                    </select>
                </div>
                <div>
                    <label for="foler-path">경로</label>
                    <input type="text" id="foler-path" placeholder="드라이브 선택후 경로를 등록해 주세요." required>
                </div>
            </div>

            <label for="reg_mem_id">작성자 아이디</label>
            <input type="hidden" name="reg_mem_idx">
            <input type="text" name="reg_mem_id" id="reg_mem_id" maxlength="50" placeholder="작성자 아이디를 정확하게 입력해 주세요." required>

            <label for="gal-pen-name">올린이</label>
            <input type="text" name="gal_pen_name" id="gal-pen-name" maxlength="50" placeholder="사이트에 표시 할 올린이를 입력해 주세요." required>
            <!-- 
            <div class="gal-type">
                <label>그룹 선택</label>
                <div>
                    <input type="radio" name="gal_type_cd" id="gal_type_cd1" value="01"> <label for="gal_type_cd1">국내</label>
                    <input type="radio" name="gal_type_cd" id="gal_type_cd2" value="02"> <label for="gal_type_cd2">세계</label>
                </div>
            </div>
             -->
            <div class="info-area" style="display:none;">
                <label for="result">결과</label>
                <textarea id="result" rows="10" required></textarea>
            </div>
            <div class="button-area">
                <button type="button" class="btn-hover color-9 form-submit">등록</button>
            </div>
        </form>
    </section>
</body>
<script type="text/javascript" src="/js/upload.js"></script>
</html>