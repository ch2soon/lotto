document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('.form-submit').addEventListener('click', async () => {
        const flag = await checkValidation();
        if(flag) {
            
            // var form = document.getElementById("upload-form");
            // form.action = "./upload_proc.php";
            // form.mothod = "POST";
            // form.submit();


            document.querySelector('.form-submit').hidden = true;
            setLoadingElement();
            try {
                const url = './upload_proc.php';
                const formData = new FormData(document.getElementById('upload-form'));
                const payload = new URLSearchParams(formData);
                const headers = new Headers({
                    // 'access-control-allow-origin': '*'
                    "Content-Type": "application/x-www-form-urlencoded"
                });
                const getData = url => fetch(url, { method: "POST", headers, body: payload });
                await getData(url).then(resp => {
                    if (resp.ok) return resp.json();
                    throw new Error('Network response was not ok.');
                }).then(res => {
                    callbackProcess(res);
                }).catch(excResp => {
                    alert("등록이 실패 했습니다.\n개발자에게 문의해 주세요.");
                    console.log('catch: ', excResp);
                });
            } catch(e) {
                console.log('error message: ' + e.message);
            }
        }
    });
});
const getMemberInfo = async () => {
    const memberId = document.getElementById("reg_mem_id");
    let flag = false;
    if(memberId.value.trim() === "") {
        alert("글쓴이 아이디를 입력해주세요.");
        return false;
    } else {
        try {
            const url = './member_info.php';
            const params = { memberId: memberId.value.trim() };
            const payload = new URLSearchParams(params).toString();
            const headers = new Headers({
                // 'access-control-allow-origin': '*'
                "Content-Type": "application/x-www-form-urlencoded"
            });
            const getData = url => fetch(url, { method: "POST", headers, body: payload });
            await getData(url).then(resp => {
                if (resp.ok) return resp.json();
                throw new Error('Network response was not ok.');
            }).then(data => {
                if( data.success ) {
                    if(typeof data.result.length === "undefined") {
                        document.querySelector('[name="reg_mem_idx"]').value = data.result.mem_idx;
                        flag = true;
                    } else {
                        alert("같은 아이디가 여러건 검색 되었습니다.\n개발자에게 문의해 주세요.");
                    }
                }
            }).catch(excResp => {
                console.log('catch: ', excResp);
            });
        } catch(e) {
            console.log('error message: ' + e.message);
        }
    }
    return flag;
}
const checkValidation = async () => {
    const driver = document.getElementById("driver");
    const folerPath = document.getElementById("foler-path");
    const galPenName = document.getElementById("gal-pen-name");
    const regMemId = document.getElementById("reg_mem_id");
    // const galTypeCd = document.querySelectorAll('[name="gal_type_cd"]');
    const regMemIdx = document.querySelector('[name="reg_mem_idx"]');
    if(driver.value.trim() === "") {
        alert("드라이브를 선택해주세요.");
        return false;
    }
    if(folerPath.value.trim() === "") {
        alert("드라이브 하위경로를 입력해주세요.");
        return false;
    }
    // let isGalTypeCdChecked = false;
    // for(i=0; i<galTypeCd.length; i++) {
    //     if(galTypeCd[i].checked) {
    //         isGalTypeCdChecked = true;
    //         break;
    //     }
    // }
    // if(!isGalTypeCdChecked) {
    //     alert("국내, 해외 여부를 선택해주세요.");
    //     return false;
    // }
    // const memInfoSet = await getMemberInfo();
    await getMemberInfo();
    if(regMemId.value.trim() === "") return false;
    if(regMemId.value.trim() !== "" && regMemIdx.value.trim() === "") {
        alert("글쓴이 정보가 확인되지 않습니다.\n다시 입력해 주세요.");
        document.querySelector('[name="reg_mem_idx"]').value = "";
        return false;
    }
    if(galPenName.value.trim() === "") {
        alert("올린이를 입력해주세요.");
        return false;
    }
    let setPath = driver.value.trim() + ":/" + folerPath.value.trim();
    document.querySelector('[name="data_path"]').value = setPath;
    if( confirm("업로드 중에는 취소 할 수 없습니다.\n정말 업로드하시겠습니까?") ) return true;
    else return false;
}
const setLoadingElement = () => {
    const maskHeight = (window.innerHeight > document.body.scrollHeight) ? window.innerHeight : document.body.scrollHeight;
    const mask = document.createElement("div");
    let maskTemplate = '';
    maskTemplate += '<div id="mask">';
    maskTemplate += '<div>등록이 시작되었습니다.<br>용량에 따라 완료 시까지 시간이 걸릴 수 있습니다.<br>로딩 마스크는 등록이 완료되면 사라집니다.</div>';
    maskTemplate += '</div>';
    mask.innerHTML = maskTemplate;
    document.querySelector('body').append(mask);
    document.getElementById('mask').setAttribute(
        "style", "opacity: 0.9; height: " + maskHeight+"px;"
    );
}
const delLoadingElement = () => {
    document.getElementById('mask').parentElement.remove();
}
const setConvert_time = (seconds) => {
    let hour = parseInt(seconds/3600) < 10 ? '0'+ parseInt(seconds/3600) : parseInt(seconds/3600);
    let min = parseInt((seconds%3600)/60) < 10 ? '0'+ parseInt((seconds%3600)/60) : parseInt((seconds%3600)/60);
    let sec = seconds % 60 < 10 ? '0'+seconds % 60 : seconds % 60;    
    let _return = '';
    if(parseInt(hour) > 0) _return += hour + "시간 ";
    if(parseInt(hour) > 0) _return += min + "분 ";
    else if(parseInt(min) > 0) _return += min + "분 ";
    if(parseInt(sec) > 0) _return += sec + "초";
    return _return;
}
const getDiffTime = (_start, _end) => {
    let start = new Date(_start);
    let end = new Date(_end);
    let diffTime = (end.getTime() - start.getTime()) / (1000);
    return setConvert_time(diffTime);
}
const setErrInfo = async (idx) => {
    try {
        const url = './err_info.php';
        const params = { acah_idx: idx };
        const payload = new URLSearchParams(params).toString();
        const headers = new Headers({
            // 'access-control-allow-origin': '*'
            "Content-Type": "application/x-www-form-urlencoded"
        });
        const getData = url => fetch(url, { method: "POST", headers, body: payload });
        await getData(url).then(resp => {
            if (resp.ok) return resp.json();
            throw new Error('Network response was not ok.');
        }).then(data => {
            if( data.success ) {
                if(Object.keys(data.result).length > 0) {
                    let result = [];
                    if(Object.keys(data.result).length === 1) result.push(data.result);
                    else result = data.result;
                    let _str = '';
                    _str += '<h3 style="margin-left:20px;">손상된 이미지파일 목록입니다.<span>(손상파일 목록은 새로고침 시 사라집니다.)</span></h3>';
                    _str += '<ol>';
                    for(i=0; i<result.length; i++) {
                        let err_file_path = result[i].err_file_path.replace(/\//g, "\\");
                        _str += '<li>'+err_file_path+'</li>';
                    }
                    _str += '</ol>';
                    const errInfo = document.createElement("div");
                    errInfo.classList.add("err-info-area");
                    errInfo.innerHTML = _str;
                    document.querySelector('body').append(errInfo);
                    let _clientHeight = document.querySelector('.err-info-area').clientHeight;
                    document.querySelector('section').style.paddingBottom = _clientHeight+'px';
                }
            }
        }).catch(excResp => {
            console.log('catch: ', excResp);
        });
    } catch(e) {
        console.log('error message: ' + e.message);
    }
}
const callbackProcess = (data) => {
    if( data.success ) {
        let diffTime = getDiffTime(data.result.time_start, data.result.time_end);
        let _alert = '';
        _alert += data.result.driectory_cnt+'개의 폴더, '+data.result.total_file_cnt+'개의 사진이 업로드 되었습니다.\n';
        if(data.result.err_file_cnt > 0) _alert += '총 '+data.result.err_file_cnt+'개의 손상된 파일이 존재하여 업로드에서 제외되었습니다.\n자세한 내용은 본문을 확인해주세요.\n';
        _alert += '\n소요시간 : '+diffTime;
        alert(_alert);
        if(data.result.err_file_cnt > 0) setErrInfo(data.result.acah_idx);
    }
    document.querySelector('.form-submit').hidden = false;
    delLoadingElement();
}