<?php
require_once "../vendor/autoload.php";

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__.'/../');
$dotenv->load();

define("AZURE_CONTAINER_NAME", "upload", false);
if($_ENV['CURRENT_MODE'] === "R") {
    define("AZURE_ACCOUNT_NAME", "dpstorageaccountimage", false);
    define("AZURE_ACCOUNT_KEY", "6zANeprw/Jte0Cg7bUSMDwmPON4CZP8r1A5Rg3wj89kN/aFs5gB+8Bxr5iiR4oZKqU+OQyQ5uiTcXMOnFHXpuA==", false);
} elseif($_ENV['CURRENT_MODE'] === "D") {
    // ### dev server account ###
    define("AZURE_ACCOUNT_NAME", "dpstorageaccountdev", false);
    define("AZURE_ACCOUNT_KEY", "oApbd7cSEQOllL88MIKOtwy9ahZ04eySW+FF+ckW4qzy3SSVTiZaMvC7qH1yCrhbKiB4eweYHzKfWiZsURgNTQ==", false);
} else {
    echo "error";
    exit;
}

use MicrosoftAzure\Storage\Blob\BlobRestProxy;
use MicrosoftAzure\Storage\Blob\Models\CreateContainerOptions;
use MicrosoftAzure\Storage\Blob\Models\ListBlobsOptions;
use MicrosoftAzure\Storage\Blob\Models\PublicAccessType;
use MicrosoftAzure\Storage\Common\ServiceException;
use MicrosoftAzure\Storage\Common\Models\Range;

$containerName = AZURE_CONTAINER_NAME;
$connectionString = "DefaultEndpointsProtocol=https;AccountName=".AZURE_ACCOUNT_NAME.";AccountKey=".AZURE_ACCOUNT_KEY;
$blobClient = BlobRestProxy::createBlobService($connectionString);

function pathUploadBlob($pathToUpload, $blob_path, $files) {
    $blob_content = $blob_path."/".$files;
    try {
        global $containerName, $blobClient;

        // Getting local file so that we can upload it to Azure
        $myfile = fopen($pathToUpload, "r") or die("Unable to open file!");
        fclose($myfile);
        
        # Upload file as a block blob
        // echo "Uploading BlockBlob: ".PHP_EOL;
        // echo $pathToUpload;
        // echo "<br />";
        
        $content = fopen($pathToUpload, "r");

        //Upload blob
        $blobClient->createBlockBlob($containerName, $blob_content, $content);
    } catch(ServiceException $e) {
        $code = $e->getCode();
        $error_message = $e->getMessage();
        echo $code.": ".$error_message."<br />";
    } catch(InvalidArgumentTypeException $e) {
        $code = $e->getCode();
        $error_message = $e->getMessage();
        echo $code.": ".$error_message."<br />";
    }
}

function listBlobsSample() {
    try {
        // List blobs.
        $listBlobsOptions = new ListBlobsOptions();
        $listBlobsOptions->setPrefix("");

        // Setting max result to 1 is just to demonstrate the continuation token.
        // It is not the recommended value in a product environment.
        $listBlobsOptions->setMaxResults(1);

        do {
            global $containerName, $blobClient;
            $blob_list = $blobClient->listBlobs($containerName, $listBlobsOptions);
            foreach ($blob_list->getBlobs() as $blob) {
                echo $blob->getName().": ".$blob->getUrl()."<br>";
            }

            $listBlobsOptions->setContinuationToken($blob_list->getContinuationToken());
        } while ($blob_list->getContinuationToken());

    } catch (ServiceException $e) {
        $code = $e->getCode();
        $error_message = $e->getMessage();
        echo $code.": ".$error_message.PHP_EOL;
    }
}