<?php
// error_reporting(E_ALL&~E_WARNING);
require_once "../vendor/autoload.php";

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__.'/../');
$dotenv->load();

define("DB_HOST", "doopedia.postgres.database.azure.com", false);
define("DB_DATABASE", "db_dsdpd", false);
if($_ENV['CURRENT_MODE'] === "R") {
    // ### real server ###
    define("DB_USER", "dp_admin", false);
    define("DB_PASSWORD", "dpdsm_0217", false);
} elseif($_ENV['CURRENT_MODE'] === "D") {
    // ### dev server ###
    define("DB_USER", "dpdev_admin", false);
    define("DB_PASSWORD", "dpdsmdev_0217", false);
} else {
    echo "error";
    exit;
}

function get_dbc() {
    $host = DB_HOST;
    $database = DB_DATABASE;
    $user = DB_USER;
    $password = DB_PASSWORD;

    $connection = pg_connect("host=$host dbname=$database user=$user password=$password") or die("Failed to create connection to database: ". pg_last_error(). "<br/>");
    return $connection;
}

function filter_SQL($content) {
	$content = str_replace("&", "&amp", $content);
	$content = str_replace("<", "&lt", $content);
	$content = str_replace(">", "&gt", $content);
	// $content = str_replace("'", "&apos", $content);
	$content = str_replace("'", "`", $content);
	$content = str_replace("\"", "&quot", $content);
	$content = str_replace("\r", "", $content);
	$content = str_replace("'", "", $content);
    $content = str_replace('"', "", $content);
	$content = str_replace("--", "", $content);
	$content = str_replace(";", "", $content);
	$content = str_replace("%", "", $content);
	$content = str_replace("+", "", $content);
	$content = str_replace("script", "", $content);
	$content = str_replace("alert", "", $content);
	$content = str_replace("cookie", "", $content);
	$content = SQL_Injection($content);
	return $content;
}
function SQL_Injection($get_Str) { 
	// return preg_replace("/( select| union| insert| update| delete| drop| and| or|\"|\'|#|\/\*|\*\/|\\\|\;)/i","", $get_Str); 
	return preg_replace("/( select| union| insert| update| delete| drop|\"|\'|#|\/\*|\*\/|\\\|\;)/i","", $get_Str); 
}

/**
 * 다중 이미지 등록시 게시물 프로세스에 필요한 내용
 * 
 *** 디렉토리 네임 룰 : 지역코드_제목_ 등등....(현재 임시) ***
 * 
 *** 아래 : 사이트에서 커뮤니티 등록시 요구사항 ***
 * 제목(한글,영어,기타)
 * 글쓴이 정보
 * 게시물 공개여부
 * `그룹`(주소등... 각 그룹마다 서브데이터가 상이함) : 자동화가 가능? 아니면 무조건 주소라서?
 * 저작권
 * 백과사전 항목연결
 * 콘텐츠
 * 키워드
 */
function set_field_data($_str) {
    $_str = filter_SQL($_str);
    // $_element = explode("_", $_str);
    // $_return = (object) array(
    //     'code' => $_element[0],
    //     'subject' => $_element[1]
    // );
    $_return = (object) array(
        'subject' => $_str
    );
    return $_return;
}

function rmdir_all($delete_path) {
    if(is_dir($delete_path)) {        
	    $dirs = dir($delete_path);

        while(false !== ($entry = $dirs->read())) {
            // 디렉토리의 내용을 하나씩 읽는다.
            if(($entry != '.') && ($entry != '..')) {
                // 디렉토리의 내용중 현재폴더, 상위폴더가 아니면 (즉 파일 및 디렉토리)            
                if(is_dir($delete_path.'/'.$entry)) {
                    //디렉토리이면 재귀호출로 다시 삭제 시작.
                    rmdir_all($delete_path.'/'.$entry);
                } else {
                    //해당 파일 삭제
                    @unlink($delete_path.'/'.$entry);
                }
            }
        }

        $dirs->close();

        // 최종 디렉토리 삭제
        @rmdir($delete_path);
    }
}

function resizeImage($resourceType, $image_width, $image_height, $resizeWidth, $resizeHeight) {
    $resizeWidth = (int) $resizeWidth;
    $resizeHeight = (int) $resizeHeight;
    $imageLayer = imagecreatetruecolor($resizeWidth, $resizeHeight);
    imagecopyresampled($imageLayer, $resourceType, 0, 0, 0, 0, $resizeWidth, $resizeHeight, $image_width, $image_height);
    return $imageLayer;
}

function thumbnail($file, $save_filename, $max_width, $max_height) {
    $_return = null;
    try {
        $img_info = getImageSize($file);
        $img_type = $img_info[2];
        $img_width = $img_info[0];
        $img_height = $img_info[1];

        switch ($img_type) {
            case IMAGETYPE_JPEG:
                $image_create = 'imagecreatefromjpeg';
                $image = 'imagejpeg';
            break;

            case IMAGETYPE_GIF:
                $image_create = 'imagecreatefromgif';
                $image = 'imagegif';
            break;

            case IMAGETYPE_PNG:
                $image_create = 'imagecreatefrompng';
                $image = 'imagepng';
            break;

            case IMAGETYPE_JPG:
                $image_create = 'imagecreatefromjpeg';
                $image = 'imagejpeg';
            break;

            default:
                return false;
            break;
        }

        if(@!$image_create($file)) {
            throw new Exception('손상된 파일 입니다.');
        }
        $im = $image_create($file);
        if($image === 'imagejpeg') {
            $exif = exif_read_data($file);
            if(!empty($exif['Orientation'])) {
                switch($exif['Orientation']) {
                    case 8:
                        $im = imagerotate($im, 90, 0);
                        $tmp_w = $img_width;
                        $img_width = $img_height;
                        $img_height = $tmp_w;
                        break;
                    case 3:
                        $im = imagerotate($im, 180, 0);
                        break;
                    case 6:
                        $im = imagerotate($im, -90, 0);
                        $tmp_w = $img_width;
                        $img_width = $img_height;
                        $img_height = $tmp_w;
                        break;
                }
            }
        }

        if($max_width === 0) $width_cal = $max_width;
        else $width_cal = $img_width/$max_width;

        if($max_height === 0) $height_cal = $max_height;
        else $height_cal = $img_height/$max_height;

        if($width_cal == $height_cal) {
            $dst_width=$max_width;
            $dst_height=$max_height;
        } elseif($width_cal < $height_cal) {
            $dst_width=$max_height*($img_width/$img_height);
            $dst_height=$max_height;
        } else {
            $dst_width=$max_width;
            $dst_height=$max_width*($img_height/$img_width);
        }
        
        $imageLayer = resizeImage($im, $img_width, $img_height, $dst_width, $dst_height);
        imageinterlace($imageLayer);
        $image($imageLayer, $save_filename);
        if($imageLayer) imagedestroy($imageLayer);
        if($im) imagedestroy($im);
        
        $_return = (object) array(
            'result' => "success"
            , 'message' => "성공"
        );
    } catch(Exception $e) {
        $_return = (object) array(
            'result' => "fail"
            , 'message' => $e->getMessage()
        );
    } finally {
        return $_return;
    }
}

function thumbnail_old($file, $save_filename, $max_width, $max_height) {
    $src_img = ImageCreateFromJPEG($file);
    $img_info = getImageSize($file);
    $img_width = $img_info[0];
    $img_height = $img_info[1];

    if($max_width === 0) $width_cal = $max_width;
    else $width_cal = $img_width/$max_width;

    if($max_height === 0) $height_cal = $max_height;
    else $height_cal = $img_height/$max_height;

    if($width_cal == $height_cal) {
        $dst_width=$max_width;
        $dst_height=$max_height;
    } elseif($width_cal < $height_cal) {
        $dst_width=$max_height*($img_width/$img_height);
        $dst_height=$max_height;
    } else {
        $dst_width=$max_width;
        $dst_height=$max_width*($img_height/$img_width);
    }

    $dst_img = imagecreatetruecolor($dst_width, $dst_height);
    // ImageCopyResized($dst_img, $src_img, 0, 0, 0, 0, $dst_width, $dst_height, $img_width, $img_height);  // 품질 저하로 변경
    imagecopyresampled($dst_img, $src_img, 0, 0, 0, 0, $dst_width, $dst_height, $img_width, $img_height);
    imageinterlace($dst_img);
    imagejPEG($dst_img, $save_filename);
    imagedestroy($dst_img);
    imagedestroy($src_img);
}

function watermark($file, $save_filename, $waterimg) {
    $imagesource = $file;
    $filetype = substr($imagesource,strlen($imagesource)-4,4);
    $filetype = strtolower($filetype);
    $rootpath = $_SERVER["DOCUMENT_ROOT"];
    if($filetype == ".gif") $image = @imagecreatefromgif($imagesource);
    if($filetype == ".jpg") $image = @imagecreatefromjpeg($imagesource);
    if($filetype == ".png") $image = @imagecreatefrompng($imagesource);
    if(!$image) die();

    if($waterimg=="400") $watermark = @imagecreatefrompng($rootpath.'/image/watermark_new/encyber_watermark_2.png');
    else if($waterimg=="800") $watermark = @imagecreatefrompng($rootpath.'/image/watermark_new/encyber_watermark_1.png');
    else $watermark = @imagecreatefrompng($rootpath.'/image/watermark_new/encyber_watermark.png');

    $imagewidth = imagesx($image);
    $imageheight = imagesy($image);
    $watermarkwidth =  imagesx($watermark);
    $watermarkheight =  imagesy($watermark);
    $startwidth = (($imagewidth - $watermarkwidth)); 
    $startheight = (($imageheight - $watermarkheight));

    imagealphablending($image, true);
    imagecopy($image, $watermark,  $startwidth, $startheight, 0, 0, $watermarkwidth, $watermarkheight);
    // header("Content-type: image/jpeg");
    imagejpeg($image, $save_filename);
    imagedestroy($image);
    imagedestroy($watermark);
}